import Data.List

-- Definição dos tipos de dados utilizados no código
type Valor = Int
type Linha a = [a]
type Matriz a = [Linha a]
type Grid = Matriz Valor
type Opcoes = [Valor]

valoresExemplo :: Grid
valoresExemplo = [[2, 0, 7, 0, 3, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0],
        [0, 4, 0, 4, 7, 6, 0, 0],
        [0, 0, 0, 0, 1, 4, 1, 3],
        [0, 0, 0, 6, 4, 3, 0, 0],
        [0, 3, 0, 0, 0, 0, 2, 0],
        [3, 0, 3, 2, 6, 0, 0, 3],
        [1, 4, 0, 0, 0, 0, 3, 0]]

gruposExemplo :: Grid
gruposExemplo =[ [1, 1, 1, 2, 2, 2, 3, 3],
                 [1, 1, 4, 4, 5, 5, 3, 6],
                 [9, 1, 8, 4, 7, 7, 7, 6],
                 [9, 1, 8, 4, 4, 7, 7, 7],
                 [10, 10, 11, 12, 12, 12, 12, 7],
                 [10, 10, 11, 15, 12, 12, 17, 17],
                 [13, 14, 15, 15, 15, 15, 16, 17],
                 [13, 13, 13, 15, 16, 16, 16, 17]]


-- Calcula a ordem de uma matriz quadrada
ordem :: Matriz m -> Int
ordem matriz = length (head matriz)

-- Obtém as linhas de uma matriz
linhas :: Matriz m -> [Linha m]
linhas matriz = matriz

-- Obtém as colunas de uma matriz
colunas :: Matriz m -> [Linha m]
colunas matriz = transpose matriz

-- Organiza tuplas (valor; grupo) para facilitar funções de resolução
matrizPorGrupo :: Eq m => Matriz m -> Grid -> Matriz m
matrizPorGrupo valores grupos = map (\grupo -> extrairGrupo grupo valoresComGrupos) gruposUnicos
  where
    -- Combina os valores e os grupos em uma lista de tuplas e concatena todas as linhas
    valoresComGrupos = concat (zipWith zip valores grupos)
    -- Extrai os grupos únicos a partir das tuplas (segunda posição da tupla)
    gruposUnicos = nub (map snd valoresComGrupos) 
    -- Função auxiliar que filtra e mapeia os valores associados a um grupo específico
    extrairGrupo grupo = map fst . filter ((== grupo) . snd)

-- Reconstrói as colunas originais a partir de uma lista de linhas divididas por blocos
colunasOriginais :: [Linha l] -> Int -> [Linha l]
colunasOriginais blocos tamanho = gerarColunas tamanho (concat blocos)
  where
    -- Função auxiliar que divide uma lista em sublistas de tamanho 'n'
    gerarColunas n = takeWhile (not . null) . map (take n) . iterate (drop n)

-- Calcula o tamanho de um grupo específico em uma matriz
tamanhoGrupo :: Eq m => m -> Matriz m -> Int
tamanhoGrupo identificador matriz = length (filter (== identificador) (concat matriz))

-- Obtém os valores já presentes em um grupo específico
valoresNoGrupo :: Eq m => Matriz m -> Grid -> Int -> [m]
valoresNoGrupo valores grupos identificador = [v | (v, g) <- concat (zipWith zip valores grupos), g == identificador]

-- Diferença entre duas listas de opções, mantendo xs se for uma lista de um único elemento
diferenca :: Opcoes -> Opcoes -> Opcoes
xs `diferenca` ys = if unicoElementoNaLista xs then xs else xs \\ ys

-- Verifica se uma lista tem apenas um único elemento
unicoElementoNaLista :: [a] -> Bool
unicoElementoNaLista [_] = True
unicoElementoNaLista _ = False

-- Gera as opções possíveis para cada célula do Grid
-- Cria uma matriz de opções possíveis para cada célula
escolhas :: Grid -> Grid -> Matriz Opcoes
escolhas valores grupos = [ [ determinarOpcoes (valor, grupo) | (valor, grupo) <- zip linhaValores linhaGrupos ] | (linhaValores, linhaGrupos) <- zip valores grupos ]
  where
    determinarOpcoes (valor, grupo)
      | valor == 0 = [1..tamanhoGrupo grupo grupos] `diferenca` valoresNoGrupo valores grupos grupo
      | otherwise = [valor]


-- Agrupa as colunas de uma matriz de acordo com os grupos
gruposPorColuna :: Eq m => Matriz m -> Grid -> [Linha m]
gruposPorColuna valores grupos = zipWith zip (colunas valores) (colunas grupos) >>= map (map fst) . groupBy (\x y -> snd x == snd y)

-- Reduz as opções possíveis em cada célula, retornando uma matriz reduzida
reduzirEscolhas :: Matriz Opcoes -> Grid -> Matriz Opcoes
reduzirEscolhas valores grupos = colunas $ colunasOriginais (map reduzirEscolhasPorLista (gruposPorColuna valores grupos)) (ordem valores)

-- Reduz as opções possíveis em uma lista de opções
reduzirEscolhasPorLista :: Linha Opcoes -> Linha Opcoes
reduzirEscolhasPorLista xss = [xs `diferenca` unicos | xs <- xss]
    where unicos = concat (filter unicoElementoNaLista xss)

-- Busca soluções para o Grid baseando-se nas opções possíveis
buscarSolucao :: Matriz Opcoes -> Grid -> [Grid]
buscarSolucao valores grupos
    | naoPossivel valores grupos = []  -- Retorna uma lista vazia se não há solução
    | all (all unicoElementoNaLista) valores = [map concat valores]  -- Retorna a solução se todas as células possuem um único valor possível
    | otherwise = [g | valores' <- expandirEscolhas valores, g <- buscarSolucao (reduzirEscolhas valores' grupos) grupos]  -- Continua a busca expandindo e reduzindo as opções

-- Verifica se o Grid não possui solução
naoPossivel :: Matriz Opcoes -> Grid -> Bool
naoPossivel valores grupos = vazio valores || not (valido valores grupos)
    where
        vazio m = any (any null) m

-- Verifica se uma matriz de opções é válida
valido :: Matriz Opcoes -> Grid -> Bool
valido valores grupos = all vizinhoValido (colunas valores) &&
                        all vizinhoValido (linhas valores) &&  -- Nenhuma célula deve ter vizinhos com o mesmo valor (em linha e coluna)
                        all linhaValida (matrizPorGrupo valores grupos) &&  -- Dentro de um grupo, não deve haver valores repetidos
                        all linhaDecrescente (gruposPorColuna valores grupos)  -- Nas colunas dentro de um grupo, os valores devem ser ordenados de forma decrescente

-- Verifica se os vizinhos em uma linha são válidos (não possuem o mesmo valor)
vizinhoValido :: Eq a => Linha [a] -> Bool
vizinhoValido [] = True
vizinhoValido [a] = True
vizinhoValido (a:b:bs)
    | (length a <= 1) && (length b <= 1) = if a == b then False else vizinhoValido (b:bs)
    | otherwise = vizinhoValido (b:bs)

-- Verifica se uma linha não possui valores repetidos
linhaValida :: Eq a => Linha [a] -> Bool
linhaValida [] = True
linhaValida (x:xs) = if (length x <= 1) then not (elem x xs) && linhaValida xs else linhaValida xs

-- Verifica se uma linha está ordenada de forma decrescente
linhaDecrescente :: Ord a => Linha [a] -> Bool
linhaDecrescente [] = True
linhaDecrescente [a] = True
linhaDecrescente (a:b:bs)
    | (length a <= 1) && (length b <= 1) = if a < b then False else linhaDecrescente (b:bs)
    | otherwise = linhaDecrescente (b:bs)

-- Expande as opções possíveis em uma matriz
expandirEscolhas :: Matriz Opcoes -> [Matriz Opcoes]
expandirEscolhas m = [linhas1 ++ [linha1 ++ [c] : linha2] ++ linhas2 | c <- cs]
    where
        (linhas1,linha:linhas2) = break (not . all unicoElementoNaLista) m
        (linha1,cs:linha2) = break (not . unicoElementoNaLista) linha

-- Encontra a solução para o Grid (retorna a primeira solução encontrada)
obterSolucao :: Grid -> Grid -> Grid
obterSolucao valores grupos = head (buscarSolucao (reduzirEscolhas (escolhas valores grupos) grupos) grupos)


main = do
    let valores = valoresExemplo
    let grupos = gruposExemplo
    print "Resolvendo..."
    mapM_ print (obterSolucao valores grupos)