#include "grafo_dirigido.cpp"
#include <algorithm>
#include <map>

void dfs_visit_ot(
    Grafo &grafo,
    Vertice &vertice,
    std::map<uint32_t, bool> &visitados,
    std::map<uint32_t, uint32_t> &tempos_visita,
    std::map<uint32_t, uint32_t> &tempos_fim,
    uint32_t &tempo,
    std::vector<Vertice> &ordenacao
) {
    visitados[vertice.getId()] = true;
    tempos_visita[vertice.getId()] = ++tempo;

    for (auto vizinho : grafo.vizinhos_saintes(vertice.getId())) {
        if (!visitados[vizinho]) {
            dfs_visit_ot(grafo, grafo.achaVertice(vizinho), visitados, tempos_visita, tempos_fim, tempo, ordenacao);
        }
    }

    tempos_fim[vertice.getId()] = ++tempo;
    ordenacao.push_back(vertice);
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, uint32_t> tempos_visita{};
    std::map<uint32_t, uint32_t> tempos_fim{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        visitados[grafo.getVertices()[i].getId()] = false;
    }
    uint32_t tempo = 0;
    std::vector<Vertice> ordenacao{};

    for (auto vertice : grafo.getVertices()) {
        if (!visitados[vertice.getId()]) {
            dfs_visit_ot(grafo, vertice, visitados, tempos_visita, tempos_fim, tempo, ordenacao);
        }
    }
    std::reverse(ordenacao.begin(), ordenacao.end());

    std::cout << ordenacao[0].getRotulo();
    for (size_t i = 1; i < ordenacao.size(); i++) {
        std::cout << "→" << ordenacao[i].getRotulo();
    }
    std::cout << std::endl;

    return 0;
}
