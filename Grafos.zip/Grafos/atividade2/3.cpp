#include "grafo_nao_dirigido.cpp"
#include <algorithm>
#include <map>

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::vector<Aresta> arvore_minima{};
    std::map<uint32_t, std::vector<Vertice>> arvores{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        Vertice vertice = grafo.getVertices()[i];
        arvores[vertice.getId()].push_back(vertice);
    }

    std::vector<Aresta> arestas_ordenadas{};
    for (auto aresta : grafo.getArestas()) arestas_ordenadas.push_back(aresta);
    std::sort(arestas_ordenadas.begin(), arestas_ordenadas.end(),
        [&](Aresta &a, Aresta &b) {
            return a.getPeso() < b.getPeso();
        });

    for (auto aresta : arestas_ordenadas) {
        if (arvores[aresta.getV1()] != arvores[aresta.getV2()]) {
            arvore_minima.push_back(aresta);
            arvores[aresta.getV1()].insert(arvores[aresta.getV1()].begin(), arvores[aresta.getV2()].begin(), arvores[aresta.getV2()].end());
            for (auto vertice : arvores[aresta.getV1()]) {
                arvores[vertice.getId()] = arvores[aresta.getV1()];
            }
        }
    }

    std::cout << arvore_minima[0].getV1() << "-" << arvore_minima[0].getV2();
    for (size_t i = 1; i < arvore_minima.size(); i++) {
        std::cout << ", " << arvore_minima[i].getV1() << "-" << arvore_minima[i].getV2();
    }
    std::cout << std::endl;

    return 0;
}
