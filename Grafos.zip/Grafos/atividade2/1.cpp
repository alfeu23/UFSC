#include "grafo_dirigido.cpp"
#include <algorithm>
#include <iostream>
#include <map>
#include <set>

void dfs_visit(
    Grafo &grafo,
    uint32_t vertice,
    std::map<uint32_t, bool> &visitados,
    std::map<uint32_t, uint32_t> &tempos_visita,
    std::map<uint32_t, uint32_t> &antecessores,
    std::map<uint32_t, uint32_t> &tempos_fim,
    uint32_t &tempo
) {
    visitados[vertice] = true;
    tempos_visita[vertice] = ++tempo;

    for (auto vizinho : grafo.vizinhos_saintes(vertice)) {
        if (!visitados[vizinho]) {
            antecessores[vizinho] = vertice;
            dfs_visit(grafo, vizinho, visitados, tempos_visita, antecessores, tempos_fim, tempo);
        }
    }

    tempos_fim[vertice] = ++tempo;
}

std::map<uint32_t, uint32_t> dfs(Grafo &grafo) {
    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, uint32_t> tempos_visita{};
    std::map<uint32_t, uint32_t> antecessores{};
    std::map<uint32_t, uint32_t> tempos_fim{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        uint32_t vertice_id = grafo.getVertices()[i].getId();
        visitados[vertice_id] = false;
        tempos_visita[vertice_id] = std::numeric_limits<uint32_t>::max();
        tempos_fim[vertice_id] = std::numeric_limits<uint32_t>::max();
    }
    uint32_t tempo = 0;

    for (auto vertice : grafo.getVertices()) {
        if (!visitados[vertice.getId()]) {
            dfs_visit(grafo, vertice.getId(), visitados, tempos_visita, antecessores, tempos_fim, tempo);
        }
    }

    return tempos_fim;
}

void dfs_visit_adaptado(
    Grafo &grafo,
    uint32_t vertice,
    std::map<uint32_t, bool> &visitados,
    std::map<uint32_t, uint32_t> &antecessores
) {
    visitados[vertice] = true;

    for (auto vizinho : grafo.vizinhos_saintes(vertice)) {
        if (!visitados[vizinho]) {
            antecessores[vizinho] = vertice;
            dfs_visit_adaptado(grafo, vizinho, visitados, antecessores);
        }
    }
}

std::map<uint32_t, uint32_t> dfs_adaptado(Grafo &grafo, std::map<uint32_t, uint32_t> &tempos_fim) {
    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, uint32_t> antecessores{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        visitados[grafo.getVertices()[i].getId()] = false;
    }
    uint32_t tempo = 0;

    std::vector<Vertice> vertices_ordenados{};
    for (auto vertice : grafo.getVertices()) vertices_ordenados.push_back(vertice);
    std::sort(vertices_ordenados.begin(), vertices_ordenados.end(),
        [&](Vertice &a, Vertice &b) {
            return tempos_fim[a.getId()] > tempos_fim[b.getId()];
        });

    for (auto vertice : vertices_ordenados) {
        if (!visitados[vertice.getId()]) {
            dfs_visit_adaptado(grafo, vertice.getId(), visitados, antecessores);
        }
    }

    return antecessores;
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    auto tempos_fim = dfs(grafo);

    std::vector<Arco> arcos_transpostos{};
    for (auto arco : grafo.getArcos()) {
        arcos_transpostos.push_back(Arco(arco.getId(), arco.getV2(), arco.getV1(), arco.getPeso()));
    }
    Grafo grafo_transposto(grafo.getVertices(), arcos_transpostos);

    auto antecessores = dfs_adaptado(grafo_transposto, tempos_fim);

    while (!antecessores.empty()) {
        std::set<uint32_t> componente{};

        for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
            uint32_t vertice_id = grafo.getVertices()[i].getId();
            if (antecessores.count(vertice_id)) {
                if (componente.empty()
                    || componente.find(vertice_id) != componente.end()
                    || componente.find(antecessores[vertice_id]) != componente.end()) {
                    componente.insert(vertice_id);
                    componente.insert(antecessores[vertice_id]);
                    antecessores.erase(vertice_id);
                }
            }
        }

        bool first = true;
        for (auto v : componente) {
            if (first) {
                first = false;
                std::cout << v;
            } else {
                std::cout << "," << v;
            }
        }
        std::cout << std::endl;
    }

    return 0;
}
