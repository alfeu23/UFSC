#include "grafo.cpp"
#include <iostream>
#include <map>

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, float> distancias{};
    std::map<uint32_t, uint32_t> anteriores{};
    for (auto vertice : grafo.getVertices()) {
        visitados[vertice.getId()] = false;
        distancias[vertice.getId()] = std::numeric_limits<float>::max();
    }

    uint32_t inicio = atoi(argv[2]);
    distancias[inicio] = 0;

    while (true) {
        bool achou = false;
        uint32_t vertice = 0;
        for (auto v : grafo.getVertices()) {
            if (!visitados[v.getId()]) {
                if (!achou || distancias[v.getId()] < distancias[vertice])
                    vertice = v.getId();
                achou = true;
            }
        }
        if (!achou) break;

        visitados[vertice] = true;
        for (auto vizinho : grafo.vizinhos(vertice)) {
            if (!visitados[vizinho]) {
                if (distancias[vizinho] > distancias[vertice] + grafo.achaAresta(vertice, vizinho).getPeso()) {
                    distancias[vizinho] = distancias[vertice] + grafo.achaAresta(vertice, vizinho).getPeso();
                    anteriores[vizinho] = vertice;
                }
            }
        }
    }

    for (auto vertice : grafo.getVertices()) {
        std::cout << vertice.getId() << ": ";

        if (vertice.getId() == inicio) {
            std::cout << vertice.getId();
        } else {
            std::vector<uint32_t> caminho{};
            uint32_t anterior = anteriores[vertice.getId()];
            caminho.push_back(anterior);
            while (anterior != inicio) {
                anterior = anteriores[anterior];
                caminho.push_back(anterior);
            }
            std::cout << caminho[caminho.size()-1];
            for (int i = caminho.size()-2; i >= 0; --i) std::cout << "," << caminho[i];
            std::cout << "," << vertice.getId();
        }

        std::cout << "; d=" << distancias[vertice.getId()] << ",";
        std::cout << std::endl;
    }

    return 0;
}
