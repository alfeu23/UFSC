#include <cstdint>
#include <fstream>
#include <limits>
#include <sstream>
#include <vector>

class Vertice {
    public:
        Vertice(uint32_t id, std::string rotulo) : id(id), rotulo(rotulo) {}

        ~Vertice() {}

        uint32_t getId() { return id; }
        std::string getRotulo() { return rotulo; }

    private:
        uint32_t id{};
        std::string rotulo{};
};

class Aresta {
    public:
        Aresta(uint32_t id, uint32_t v1, uint32_t v2, float peso) : id(id), v1(v1), v2(v2), peso(peso) {}

        ~Aresta() {}

        bool contains(Vertice vertice) { return vertice.getId() == v1 || vertice.getId() == v2; }

        uint32_t getId() { return id; }
        uint32_t getV1() { return v1; }
        uint32_t getV2() { return v2; }
        float getPeso() { return peso; }

    private:
        uint32_t id{};
        uint32_t v1{};
        uint32_t v2{};
        float peso{};
};

class Grafo {
    public:
        Grafo(std::string arquivo) {
            std::ifstream file(arquivo);
            if (!file.is_open()) throw std::runtime_error("nao foi possivel abrir o arquivo");

            std::string line;
            uint32_t n_vertices;
            std::getline(file, line);
            std::stringstream iss(line);
            std::string a;
            iss >> a >> n_vertices;

            for (size_t i = 0; i < n_vertices; ++i) {
                uint32_t id;
                std::string rotulo;
                file >> id >> rotulo;
                Vertice vertice(id, rotulo);
                vertices.push_back(vertice);
            }
            std::getline(file, line);

            uint32_t id = 0;
            while (std::getline(file, line)) {
                uint32_t v1, v2;
                float peso;
                file >> v1 >> v2 >> peso;
                arestas.push_back(Aresta(id, v1, v2, peso));
                ++id;
            }
            arestas.pop_back();
            file.close();

            /* for (auto vertice : vertices) std::cout << vertice.getId() << ", " << vertice.getRotulo() << std::endl; */
            /* for (auto aresta : arestas) std::cout << aresta.getV1() << ", " << aresta.getV2() << ", " << aresta.getPeso() << std::endl; */
        }

        ~Grafo() {}

        std::vector<Vertice> &getVertices() { return vertices; }
        std::vector<Aresta> &getArestas() { return arestas; }

        uint32_t qtdVertices() { return vertices.size(); }
        uint32_t qtdArestas() { return arestas.size(); }

        uint32_t grau(uint32_t vertice) {
            return vizinhos(vertice).size();
        }

        std::string rotulo(Vertice &vertice) { return vertice.getRotulo(); }

        std::vector<uint32_t> vizinhos(uint32_t vertice) {
            std::vector<uint32_t> vizinhos;
            for (auto aresta : arestas) {
                if (aresta.getV1() == vertice) vizinhos.push_back(aresta.getV2());
                else if (aresta.getV2() == vertice) vizinhos.push_back(aresta.getV1());
            }
            return vizinhos;
        }

        Aresta &achaAresta(uint32_t v1, uint32_t v2) {
            for (auto &aresta : arestas) {
                if ((aresta.getV1() == v1 && aresta.getV2() == v2)
                    || (aresta.getV2() == v1 && aresta.getV1() == v2)) {
                    return aresta;
                }
            }
            return arestas[0];
        }

        bool haAresta(uint32_t v1, uint32_t v2) {
            for (auto aresta : arestas) {
                if ((aresta.getV1() == v1 && aresta.getV2() == v2)
                    || (aresta.getV2() == v1 && aresta.getV1() == v2)) {
                    return true;
                }
            }
            return false;
        }

        uint32_t idAresta(uint32_t v1, uint32_t v2) {
            for (auto aresta : arestas) {
                if ((aresta.getV1() == v1 && aresta.getV2() == v2)
                    || (aresta.getV2() == v1 && aresta.getV1() == v2)) {
                    return aresta.getId();
                }
            }
            return std::numeric_limits<uint32_t>::max();
        }

        float peso(Vertice &v1, Vertice &v2) {
            for (auto aresta : arestas) {
                if ((aresta.getV1() == v1.getId() && aresta.getV2() == v2.getId())
                    || (aresta.getV2() == v1.getId() && aresta.getV1() == v2.getId())) {
                    return aresta.getPeso();
                }
            }
            return std::numeric_limits<float>::max();
        }

    private:
        std::vector<Vertice> vertices{};
        std::vector<Aresta> arestas{};
};
