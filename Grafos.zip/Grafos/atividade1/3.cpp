#include "grafo.cpp"
#include <iostream>
#include <map>

std::vector<uint32_t> buscar_subciclo(Grafo &grafo, uint32_t vertice, std::map<size_t, bool> &visitadas) {
    std::vector<uint32_t> ciclo{vertice};
    uint32_t t = vertice;
    do {
        bool achou = false;
        for (auto vizinho : grafo.vizinhos(vertice)) {
            uint32_t aresta = grafo.idAresta(vertice, vizinho);
            if (!visitadas[aresta]) {
                achou = true;
                visitadas[aresta] = true;
                vertice = vizinho;
                ciclo.push_back(vertice);
                break;
            }
        }
        if (!achou) return std::vector<uint32_t>{};
    } while (t != vertice);

    for (size_t i = 0; i < ciclo.size(); ++i) {
        auto vertice = ciclo[i];
        for (auto vizinho : grafo.vizinhos(vertice)) {
            uint32_t aresta = grafo.idAresta(vertice, vizinho);
            if (!visitadas[aresta]) {
                auto novo_ciclo = buscar_subciclo(grafo, vertice, visitadas);
                if (novo_ciclo.empty()) return std::vector<uint32_t>{};

                auto pos = ciclo.begin();
                for (size_t i = 0; i < ciclo.size(); ++i) {
                    if (ciclo[i] == novo_ciclo[0]) {
                        pos = ciclo.begin() + i;
                        break;
                    }
                }
                pos = ciclo.erase(pos);
                ciclo.insert(pos, novo_ciclo.begin(), novo_ciclo.end());

                break;
            }
        }
    }

    return ciclo;
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::map<size_t, bool> visitadas{};
    for (auto aresta : grafo.getArestas()) {
        visitadas[aresta.getId()] = false;
    }

    uint32_t vertice = grafo.getArestas()[0].getV1();
    auto ciclo = buscar_subciclo(grafo, vertice, visitadas);

    if (ciclo.empty()) {
        std::cout << 0 << std::endl;
        return 0;
    }

    for (auto aresta : grafo.getArestas()) {
        if (!visitadas[aresta.getId()]) {
            std::cout << 0 << std::endl;
            return 0;
        }
    }

    std::cout << 1 << std::endl;
    std::cout << ciclo[0];
    for (size_t i = 1; i < ciclo.size(); ++i) {
        std::cout << "," << ciclo[i];
    }
    std::cout << std::endl;

    return 0;
}
