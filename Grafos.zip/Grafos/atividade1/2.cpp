#include "grafo.cpp"
#include <iostream>
#include <map>
#include <queue>

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, int32_t> distancias{};
    std::vector<std::vector<uint32_t>> vertices_por_distancia(grafo.qtdVertices());
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        auto vertice = grafo.getVertices()[i];
        visitados[vertice.getId()] = false;
        distancias[vertice.getId()] = std::numeric_limits<int32_t>::max();
        vertices_por_distancia[i] = std::vector<uint32_t>{};
    }

    uint32_t inicio = atoi(argv[2]);
    visitados[inicio] = true;
    distancias[inicio] = 0;
    vertices_por_distancia[0].push_back(inicio);

    std::queue<uint32_t> fila{};
    fila.push(inicio);

    size_t i = 1;
    while (!fila.empty()) {
        uint32_t vertice = fila.front();
        fila.pop();
        for (auto vizinho : grafo.vizinhos(vertice)) {
            if (!visitados[vizinho]) {
                visitados[vizinho] = true;
                distancias[vizinho] = distancias[vertice] + 1;
                fila.push(vizinho);
                vertices_por_distancia[distancias[vizinho]].push_back(vizinho);
            }
        }
        ++i;
    }

    for (size_t i = 0; i < vertices_por_distancia.size(); ++i) {
        if (vertices_por_distancia[i].empty()) break;
        std::cout << i << ": " << vertices_por_distancia[i][0];
        for (size_t j = 1; j < vertices_por_distancia[i].size(); ++j) {
            auto vertice = vertices_por_distancia[i][j];
            std::cout << "," << vertice;
        }
        std::cout << std::endl;
    }

    return 0;
}
