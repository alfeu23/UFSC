#include "grafo.cpp"
#include <iostream>

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    uint32_t n_vertices = grafo.qtdVertices();
    std::vector<std::vector<std::vector<float>>> matrizes{};
    for (size_t k = 0; k <= n_vertices; ++k) {
        std::vector<std::vector<float>> matriz{};
        for (size_t u = 0; u < n_vertices; ++u) {
            std::vector<float> linha{};
            for (size_t v = 0; v < n_vertices; ++v) {
                if (u == v) linha.push_back(0);
                else if (grafo.haAresta(u+1, v+1)) linha.push_back(grafo.achaAresta(u+1, v+1).getPeso());
                else linha.push_back(std::numeric_limits<float>::max());

            }
            matriz.push_back(linha);
        }
        matrizes.push_back(matriz);
    }

    for (size_t k = 1; k <= n_vertices; ++k) {
        for (size_t u = 0; u < n_vertices; ++u) {
            for (size_t v = 0; v < n_vertices; ++v) {
                matrizes[k][u][v] = std::min(matrizes[k-1][u][v], matrizes[k-1][u][k-1] + matrizes[k-1][k-1][v]);
            }
        }
    }

    for (size_t u = 0; u < n_vertices; ++u) {
        std::cout << u+1 << ":";
        std::cout << matrizes[n_vertices][u][0];
        for (size_t v = 1; v < n_vertices; ++v) {
            std::cout << "," << matrizes[n_vertices][u][v];
        }
        std::cout << std::endl;
    }

    return 0;
}
