#include "grafo_nao_dirigido.cpp"
#include <cstdint>
#include <limits>
#include <map>
#include <queue>

std::vector<int> biparticao(Grafo &grafo) {
    int inicio = grafo.getVertices()[0].getId();

    std::map<int, bool> visitados{};
    std::map<int, bool> adicionados{};
    std::map<int, int> antecessores{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        visitados[grafo.getVertices()[i].getId()] = false;
        adicionados[grafo.getVertices()[i].getId()] = false;
    }
    visitados[inicio] = true;
    adicionados[inicio] = true;

    std::vector<int> particao = {inicio};

    std::queue<int> fila{};
    fila.push(inicio);

    while (!fila.empty()) {
        int vertice = fila.front();
        fila.pop();
        for (auto vizinho : grafo.vizinhos(vertice)) {
            if (!visitados[vizinho]) {
                visitados[vizinho] = true;
                antecessores[vizinho] = vertice;

                if (!adicionados[vertice]) {
                    particao.push_back(vizinho);
                    adicionados[vizinho] = true;
                }

                fila.push(vizinho);
            }
        }
    }

    return particao;
}

bool bfs(Grafo &grafo, std::vector<int> &particao, std::map<int, int> &emparelhamentos, std::map<int, int> &distancias) {
    std::queue<int> fila{};

    for (auto vertice : particao) {
        if (emparelhamentos[vertice] == -1) {
            distancias[vertice] = 0;
            fila.push(vertice);
        } else {
            distancias[vertice] = std::numeric_limits<int>::max();
        }
    }

    distancias[-1] = std::numeric_limits<int>::max();

    while (!fila.empty()) {
        int vertice = fila.front();
        fila.pop();
        if (distancias[vertice] < distancias[-1]) {
            for (auto vizinho : grafo.vizinhos(vertice)) {
                if (distancias[emparelhamentos[vizinho]] == std::numeric_limits<int>::max()) {
                    distancias[emparelhamentos[vizinho]] = distancias[vertice] + 1;
                    fila.push(emparelhamentos[vizinho]);
                }
            }
        }
    }

    return distancias[-1] != std::numeric_limits<int>::max();
}

bool dfs(Grafo &grafo, std::map<int, int> &emparelhamentos, std::map<int, int> &distancias, int vertice) {
    if (vertice == -1) return true;

    for (auto vizinho : grafo.vizinhos(vertice)) {
        if (distancias[emparelhamentos[vizinho]] == distancias[vertice] + 1) {
            if (dfs(grafo, emparelhamentos, distancias, emparelhamentos[vizinho])) {
                emparelhamentos[vizinho] = vertice;
                emparelhamentos[vertice] = vizinho;
                return true;
            }
        }
    }

    distancias[vertice] = std::numeric_limits<int>::max();
    return false;
}

int hopcroft_karp(Grafo &grafo, std::vector<int> particao, std::map<int, int> &emparelhamentos) {
    std::map<int, int> distancias{};
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        auto vertice_id = grafo.getVertices()[i].getId();
        distancias[vertice_id] = std::numeric_limits<int>::max();
        emparelhamentos[vertice_id] = -1;
    }
    int tamanho = 0;

    while (bfs(grafo, particao, emparelhamentos, distancias)) {
        for (auto vertice : particao) {
            if (emparelhamentos[vertice] == -1) {
                if (dfs(grafo, emparelhamentos, distancias, vertice)) {
                    tamanho++;
                }
            }
        }
    }

    return tamanho;
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    auto particao = biparticao(grafo);

    std::map<int, int> emparelhamentos{};
    int tamanho = hopcroft_karp(grafo, particao, emparelhamentos);

    std::cout << tamanho << std::endl;

    std::map<uint32_t, bool> mostrados{};
    bool primeiro = true;
    for (size_t i = 0; i < grafo.qtdVertices(); ++i) {
        auto vertice_id = grafo.getVertices()[i].getId();
        mostrados[vertice_id] = false;
        if (mostrados[emparelhamentos[vertice_id]]) continue;
        if (!primeiro) std::cout << ", ";
        primeiro = false;
        std::cout << vertice_id << "-" << emparelhamentos[vertice_id];
        mostrados[vertice_id] = true;
    }
    std::cout << std::endl;

    return 0;
}
