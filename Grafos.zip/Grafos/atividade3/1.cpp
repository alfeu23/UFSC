#include "grafo_dirigido.cpp"
#include <algorithm>
#include <map>
#include <queue>

bool edmonds_karp_bfs(uint32_t fonte, uint32_t destino, Grafo &residual, std::vector<uint32_t> &caminho, float &capacidade) {
    caminho.clear();
    capacidade = std::numeric_limits<float>::max();

    std::map<uint32_t, bool> visitados{};
    std::map<uint32_t, uint32_t> antecessores{};
    for (size_t i = 0; i < residual.qtdVertices(); ++i) {
        visitados[residual.getVertices()[i].getId()] = false;
    }
    visitados[fonte] = true;

    std::queue<uint32_t> fila{};
    fila.push(fonte);

    while (!fila.empty()) {
        uint32_t vertice = fila.front();
        fila.pop();
        for (auto vizinho : residual.vizinhos_saintes(vertice)) {
            float peso = residual.achaArco(vertice, vizinho).getPeso();
            if (!visitados[vizinho] && peso > 0) {
                if (peso < capacidade) capacidade = peso;

                visitados[vizinho] = true;
                antecessores[vizinho] = vertice;

                if (vizinho == destino) {
                    caminho.push_back(destino);
                    auto w = destino;
                    while (w != fonte) {
                        w = antecessores[w];
                        caminho.push_back(w);
                    }

                    std::reverse(caminho.begin(), caminho.end());
                    return true;
                }

                fila.push(vizinho);
            }
        }
    }

    return false;
}

float ford_fulkerson(uint32_t fonte, uint32_t destino, Grafo &residual) {
    float fluxo_maximo = 0;

    std::vector<uint32_t> caminho = {};
    float capacidade;
    while (edmonds_karp_bfs(fonte, destino, residual, caminho, capacidade)) {
        fluxo_maximo += capacidade;

        for (size_t i = 0; i < caminho.size()-1; i++) {
            Arco &arco = residual.achaArco(caminho[i], caminho[i+1]);
            float peso = arco.getPeso();
            arco.setPeso(peso - capacidade);

            Arco &arco_residual = residual.achaArco(caminho[i+1], caminho[i]);
            peso = arco_residual.getPeso();
            arco_residual.setPeso(peso + capacidade);
        }
    }

    return fluxo_maximo;
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::vector<Arco> arcos_residuais{};
    for (auto arco : grafo.getArcos()) {
        arcos_residuais.push_back(Arco(arco.getId(), arco.getV1(), arco.getV2(), arco.getPeso()));
        arcos_residuais.push_back(Arco((arco.getId()+1)*2, arco.getV2(), arco.getV1(), 0));
    }
    Grafo residual(grafo.getVertices(), arcos_residuais);

    float fluxo_maximo = ford_fulkerson(
        grafo.getVertices()[0].getId(),
        grafo.getVertices()[grafo.qtdVertices()-1].getId(),
        residual);

    std::cout << fluxo_maximo << std::endl;

    return 0;
}
