#include "grafo_nao_dirigido.cpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <sys/types.h>

std::vector<std::vector<uint32_t>> conjuntos_independentes_maximais(Grafo &grafo) {
    std::vector<std::vector<uint32_t>> subconjuntos{};
    std::vector<bool> removidos{};
    for (size_t i = 0; i < std::pow(2, grafo.qtdVertices()); i++) {
        std::vector<uint32_t> subconjunto{};
        size_t k = i;
        for (size_t j = 0; j < grafo.qtdVertices(); j++) {
            if (k & 1) {
                subconjunto.push_back(grafo.getVertices()[j].getId());
            }
            k >>= 1;
        }
        subconjuntos.push_back(subconjunto);
        removidos.push_back(false);
    }

    std::vector<std::vector<uint32_t>> r{};

    std::sort(subconjuntos.begin(), subconjuntos.end(),
        [](std::vector<uint32_t> &a, std::vector<uint32_t> &b) {
            return a.size() > b.size();
        });

    for (size_t i = 0; i < subconjuntos.size(); i++) {
        if (removidos[i]) continue;

        auto subconjunto = subconjuntos[i];
        bool independente = true;
        for (auto u : subconjunto) {
            for (auto v : subconjunto) {
                if (grafo.haAresta(u, v)) {
                    independente = false;
                    break;
                }
            }
            if (!independente) break;
        }

        if (independente) {
            for (size_t j = 0; j < subconjuntos.size(); j++) {
                if (std::all_of(subconjuntos[j].begin(), subconjuntos[j].end(),
                    [&subconjunto](uint32_t v){ return std::find(subconjunto.begin(), subconjunto.end(), v) != subconjunto.end(); })) {

                    removidos[j] = true;
                }
            }
            r.push_back(subconjunto);
        }
    }

    return r;
}

int main(int argc, char *argv[]) {
    Grafo grafo(argv[1]);

    std::vector<uint32_t> vetor{};
    for (size_t i = 0; i < std::pow(2, grafo.qtdVertices()); i++) {
        vetor.push_back(std::numeric_limits<uint32_t>::max());
    }
    vetor[0] = 0;

    std::vector<std::vector<uint32_t>> subconjuntos{};
    for (size_t i = 0; i < std::pow(2, grafo.qtdVertices()); i++) {
        std::vector<uint32_t> subconjunto{};
        size_t k = i;
        for (size_t j = 0; j < grafo.qtdVertices(); j++) {
            if (k & 1) {
                subconjunto.push_back(grafo.getVertices()[j].getId());
            }
            k >>= 1;
        }
        subconjuntos.push_back(subconjunto);
    }

    for (size_t i = 0; i < std::pow(2, grafo.qtdVertices()); i++) {
        auto subconjunto = subconjuntos[i];
        if (subconjunto.size() == 0) continue;

        vetor[i] = std::numeric_limits<uint32_t>::max();

        std::vector<Vertice> vertices_subgrafo{};
        for (auto id : subconjunto) {
            auto vertice = grafo.achaVertice(id);
            vertices_subgrafo.push_back(Vertice(vertice.getId(), vertice.getRotulo()));
        }

        std::vector<Aresta> arestas_subgrafo{};
        for (auto aresta : grafo.getArestas()) {
            if (std::find_if(vertices_subgrafo.begin(),vertices_subgrafo.end(),
                    [&aresta](Vertice &v) { return (v.getId() == aresta.getV1()); }) != vertices_subgrafo.end()
                && std::find_if(vertices_subgrafo.begin(),vertices_subgrafo.end(),
                    [&aresta](Vertice &v) { return (v.getId() == aresta.getV2()); }) != vertices_subgrafo.end()) {

                arestas_subgrafo.push_back(Aresta(aresta.getId(), aresta.getV1(), aresta.getV2(), aresta.getPeso()));
            }
        }

        Grafo subgrafo(vertices_subgrafo, arestas_subgrafo);
        auto independentes = conjuntos_independentes_maximais(subgrafo);

        for (auto independente : independentes) {
            std::vector<uint32_t> si{};
            for (auto v : subconjunto) {
                if (std::find(independente.begin(), independente.end(), v) == independente.end()) {
                    si.push_back(v);
                }
            }
            size_t in = 0;
            for (auto v : si) {
                size_t a = 1;
                for (size_t j = 0; j < v-1; j++) {
                    a <<= 1;
                }
                in += a;
            }

            if (vetor[in] + 1 < vetor[i]) {
                vetor[i] = vetor[in] + 1;
            }
        }
    }

    std::cout << vetor[std::pow(2, grafo.qtdVertices())-1] << std::endl;

    return 0;
}
