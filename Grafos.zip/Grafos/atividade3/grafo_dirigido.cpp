#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>

class Vertice {
    public:
        Vertice(uint32_t id, std::string rotulo) : id(id), rotulo(rotulo) {}

        ~Vertice() {}

        uint32_t getId() { return id; }
        std::string getRotulo() { return rotulo; }

    private:
        uint32_t id{};
        std::string rotulo{};
};

class Arco {
    public:
        Arco(uint32_t id, uint32_t v1, uint32_t v2, float peso) : id(id), v1(v1), v2(v2), peso(peso) {}

        ~Arco() {}

        bool contains(Vertice vertice) { return vertice.getId() == v1 || vertice.getId() == v2; }

        uint32_t getId() { return id; }
        uint32_t getV1() { return v1; }
        uint32_t getV2() { return v2; }
        float getPeso() { return peso; }

        void setPeso(float peso) { this->peso = peso; }

    private:
        uint32_t id{};
        uint32_t v1{};
        uint32_t v2{};
        float peso{};
};

class Grafo {
    public:
        Grafo(std::string arquivo) {
            std::ifstream file(arquivo);
            if (!file.is_open()) throw std::runtime_error("nao foi possivel abrir o arquivo");

            std::string line;
            std::getline(file, line);
            while (std::getline(file, line)) {
                if (line[0] == '*') break;

                size_t space = line.find(' ');
                uint32_t id = std::atoi(line.substr(0, space).data());
                std::string rotulo = line.substr(space+1, line.size()-1);
                Vertice vertice(id, rotulo);
                vertices.push_back(vertice);
            }

            uint32_t id = 0;
            do {
                uint32_t v1, v2;
                float peso;
                file >> v1 >> v2 >> peso;
                arcos.push_back(Arco(id, v1, v2, peso));
                ++id;
            } while (std::getline(file, line));
            arcos.pop_back();
            file.close();

            /* for (auto vertice : vertices) std::cout << vertice.getId() << ", " << vertice.getRotulo() << std::endl; */
            /* for (auto aresta : arestas) std::cout << aresta.getV1() << ", " << aresta.getV2() << ", " << aresta.getPeso() << std::endl; */
        }

        Grafo(std::vector<Vertice> vertices, std::vector<Arco> arcos) : vertices(vertices), arcos(arcos) {}

        ~Grafo() {}

        std::vector<Vertice> &getVertices() { return vertices; }
        std::vector<Arco> &getArcos() { return arcos; }

        uint32_t qtdVertices() { return vertices.size(); }
        uint32_t qtdArcos() { return arcos.size(); }

        uint32_t grau(uint32_t vertice) {
            return grau_saintes(vertice) + grau_entrantes(vertice);
        }

        uint32_t grau_saintes(uint32_t vertice) {
            return vizinhos_saintes(vertice).size();
        }

        uint32_t grau_entrantes(uint32_t vertice) {
            return vizinhos_entrantes(vertice).size();
        }

        std::string rotulo(Vertice &vertice) { return vertice.getRotulo(); }

        std::vector<uint32_t> vizinhos_saintes(uint32_t vertice) {
            std::vector<uint32_t> vizinhos;
            for (auto arco : arcos) {
                if (arco.getV1() == vertice) vizinhos.push_back(arco.getV2());
            }
            return vizinhos;
        }

        std::vector<uint32_t> vizinhos_entrantes(uint32_t vertice) {
            std::vector<uint32_t> vizinhos;
            for (auto arco : arcos) {
                if (arco.getV2() == vertice) vizinhos.push_back(arco.getV1());
            }
            return vizinhos;
        }

        Vertice &achaVertice(uint32_t v) {
            for (auto &vertice : vertices) {
                if (vertice.getId() == v) {
                    return vertice;
                }
            }
            return vertices[0];
        }

        Arco &achaArco(uint32_t v1, uint32_t v2) {
            for (auto &arco : arcos) {
                if ((arco.getV1() == v1 && arco.getV2() == v2)) {
                    return arco;
                }
            }
            return arcos[0];
        }

        bool haArco(uint32_t v1, uint32_t v2) {
            for (auto arco : arcos) {
                if ((arco.getV1() == v1 && arco.getV2() == v2)) {
                    return true;
                }
            }
            return false;
        }

        uint32_t idArco(uint32_t v1, uint32_t v2) {
            for (auto arco : arcos) {
                if ((arco.getV1() == v1 && arco.getV2() == v2)) {
                    return arco.getId();
                }
            }
            return std::numeric_limits<uint32_t>::max();
        }

        float peso(Vertice &v1, Vertice &v2) {
            for (auto arco : arcos) {
                if ((arco.getV1() == v1.getId() && arco.getV2() == v2.getId())) {
                    return arco.getPeso();
                }
            }
            return std::numeric_limits<float>::max();
        }

    private:
        std::vector<Vertice> vertices{};
        std::vector<Arco> arcos{};
};
