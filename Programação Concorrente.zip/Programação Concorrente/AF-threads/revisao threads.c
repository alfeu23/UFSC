#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <pthread.h>



//Exercicío 1 threads
int contador_global = 0;

void* somador(void *arg) {
    int n_loops = *((int*)arg);
    for (int i = 0; i < n_loops; i++) {
        contador_global++;
    }
    return 0;
}

int main(int argc, char** argv) {
    int n_threads = atoi(argv);
    int n_loops = atoi(argv);

    pthread_t thread[n_threads];

    for (int i = 0; i < n_threads; i++) {
        pthread_create(&thread, NULL, somador, &n_loops);
    }

    for (int i = 0; i < n_threads; i++) {
        pthread_join(thread[i], NULL);
    }

    printf("Contador: %d\n", contador_global);
    printf("Esperado: %d\n", n_threads*n_loops);
}

