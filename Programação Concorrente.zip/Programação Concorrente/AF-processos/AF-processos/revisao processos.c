#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>


//Exercicio 1 Processos
int main(int agrc, char** argv) {
    int pid;
    int pid1;

    pid = fork();

    if (pid == 0) {
        printf("Processo pai criou %d\n", getpid());
        
    } else {
        pid1 = fork();
        if (pid1 == 0) {
            printf("Processo pai criou %d\n", getpid());

        } else {
            while (wait(NULL)>=0);
            printf("Processo pai finalizado");
        }
    }
    return 0;
}

//Exercicio 2 Processos
int main(int argc, char** argv) {
    printf("Processo pai inicializado\n");

    for (int i = 0; i < 2; i++) {
        int pid;
        
        pid = fork();

        if (pid == 0) {
            printf("Processo %d, filho de %d\n", getpid(), getppid());

            for (int j = 0; j < 3; j++) {
                int pid1;

                pid1 = fork();

                if (pid1 == 0) {
                    printf("Processo %d, filho de %d\n", getpid(), getppid());
                    exit(0);
                }
            }
        for (int j = 0; j < 3; j++) {
            wait(NULL);
        }
        
        printf("Processo %d finalizado", getpid());
        exit(0);
        }
    for (int i = 0; i < 2; i++) {
        wait(NULL);
    }
    printf("Processo %d finalizdo", getpid());
    exit(0);
    }
    printf("Processo pai %d finalizado\n", getpid());
    return 0;
}
// Pai é bom de forma inusitada