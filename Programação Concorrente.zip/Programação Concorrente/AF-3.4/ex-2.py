from time import sleep
from random import randint
from threading import Thread, Semaphore

def produtor():
    global buffer
    for i in range(10):
        sem_tambuffer.acquire()
        sleep(randint(0, 2))  # fica um tempo produzindo...
        item = 'item ' + str(i)
        # verifica se há lugar no buffer
        sem_buffer.acquire()
        buffer.append(item)
        print('Produzido %s (ha %i itens no buffer)' % (item, len(buffer)))
        sem_buffer.release()
        sem_tambuffer.release()

def consumidor():
    global buffer
    for i in range(10):
        # aguarda que haja um item para consumir
        sem_buffer.acquire()
        item = buffer.pop(0)
        print('Consumido %s (ha %i itens no buffer)' % (item, len(buffer)))
        sem_buffer.release()
        sleep(randint(0, 2))  # fica um tempo consumindo...
        sem_tambuffer.release()

buffer = []
tam_buffer = 3

# cria semáforos
sem_buffer = Semaphore(value=1)
sem_tambuffer = Semaphore(value=tam_buffer)

# cria threads
produtor_thread = Thread(target=produtor)
consumidor_thread = Thread(target=consumidor)

# inicia as threads
produtor_thread.start()
consumidor_thread.start()

# aguarda as threads terminarem
produtor_thread.join()
consumidor_thread.join()
