#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <pthread.h>


//Exercicio 1 Mutex
int contador_global = 0;
pthread_mutex_t mutex;

void* somador(void *arg) {
    int n_loops;
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < n_loops; i++) {
        contador_global++;
    }
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main(int argv, char** argc) {
    int n_threads = atoi; 
    int n_loops = atoi;

    pthread_t thread[n_threads];

    for (int i = 0; i < n_threads; i++) {
        pthread_create(&thread[i], NULL, somador, &n_loops);
    }

    for (int i = 0; i < n_threads; i++) {
        pthread_join(thread[i], NULL);
    }

    printf("Esperado: %d\n", contador_global);
    printf("Contador: %d\n", n_loops*n_threads);
}