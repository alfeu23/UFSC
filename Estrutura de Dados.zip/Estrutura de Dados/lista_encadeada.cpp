//! Copyright [2023] <PEDRO ALFEU WOLFF LEMOS>
#ifndef STRUCTURES_LINKED_LIST_H
#define STRUCTURES_LINKED_LIST_H

#include <cstdint>


namespace structures {

//! ...
template<typename T>
class LinkedList {
 public:
    //! ...
    LinkedList();  // construtor padrão
    //! ...
    ~LinkedList();  // destrutor
    //! ...
    void clear();  // limpar lista
    //! ...
    void push_back(const T& data);  // inserir no fim
    //! ...
    void push_front(const T& data);  // inserir no início
    //! ...
    void insert(const T& data, std::size_t index);  // inserir na posição
    //! ...
    void insert_sorted(const T& data);  // inserir em ordem
    //! ...
    T& at(std::size_t index);  // acessar um elemento na posição index
    //! ...
    T pop(std::size_t index);  // retirar da posição
    //! ...
    T pop_back();  // retirar do fim
    //! ...
    T pop_front();  // retirar do início
    //! ...
    void remove(const T& data);  // remover específico
    //! ...
    bool empty() const;  // lista vazia
    //! ...
    bool contains(const T& data) const;  // contém
    //! ...
    std::size_t find(const T& data) const;  // posição do dado
    //! ...
    std::size_t size() const;  // tamanho da lista

    void invert();
    LinkedList<T> clone();
    LinkedList<T> slicing(int start, int stop, int step);
    void append(structures::LinkedList<T> &list_add);
    LinkedList< LinkedList<T> *> halve();

 private:
    class Node {  // Elemento
     public:
        explicit Node(const T& data):
            data_{data}
        {}

        Node(const T& data, Node* next):
            data_{data},
            next_{next}
        {}

        T& data() {  // getter: dado
            return data_;
        }

        const T& data() const {  // getter const: dado
            return data_;
        }

        Node* next() {  // getter: próximo
            return next_;
        }

        const Node* next() const {  // getter const: próximo
            return next_;
        }

        void next(Node* node) {  // setter: próximo
            next_ = node;
        }

     private:
        T data_;
        Node* next_{nullptr};
    };

    Node* end() {  // último nodo da lista
        auto it = head;
        for (auto i = 1u; i < size(); ++i) {
            it = it->next();
        }
        return it;
    }

    Node* head{nullptr};
    std::size_t size_{0u};
};

}  // namespace structures

#endif

// Para a prova prática 1, temos que fazer 5 funções novas
// (1) inverter a lista -> Primeiro elemento passa a ser o utlimo e vai indo
// void invert()
// (2) duplica a lista
// LinkedList<T> clone()
// (3) cria uma lista que salta uma posição de memoria
// LinkedList<T> slicing(int start, int stop, int step)
// (4) acrescentar uma lista ao final
// void append(structures::LinkedList<T> &list_add)
// (5) criar uma lista contendo outras duas listas:
    //     a primeira, correspondente aos dados em posições pares
    //     a segunda, correspondente aos dados em posições ímpares
//LinkedList< LinkedList<T> * > halve();

//(1)
template<typename T>
void structures::LinkedList<T>::invert() {
    Node* current = head;
    Node *prev = NULL, *next = NULL;

    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev;
}

//(2)
template<typename T>
structures::LinkedList<T> structures::LinkedList<T>::clone() {
    LinkedList<T> list_clone;
    for (size_t i = 0; i < size; i++) {
        list_clone.push_back(at(i));
    }
    return list_clone;
}  

//(3)
template<typename T>
structures::LinkedList<T> structures::LinkedList<T>::slicing(int start, int stop, int step) {
    LinkedList<T> list_slice;
    for (int i = start; i < stop; i+= step) {
        list_slice.push_back(at(i));
    }
    return list_slice;
}

//(4)
template<typename T>
void structures::LinkedList<T>::append(structures::LinkedList<T> &list_add) {
    for (size_t i = 0; i < list_add.size(); i++) {
        push_back(list_add.at(i));
    }
}

//(5)
template<typename T>
structures::LinkedList< structures::LinkedList<T> *>
structures::LinkedList<T>::halve(){
    LinkedList< LinkedList<T> * > list_halve;
    LinkedList<T> impares = new LinkedList();
    LinkedList<T> pares = new LinkedList();
    for(size_t i = 0; i < size(); i++) {
        if (i % 2 == 0) {
            pares->push_back(at(i));
        } else {
            impares->push_back(at(i));
        }
    }
    list_halve.push_back(impares);
    list_halve.push_back(pares);
    return list_halve;
}


template<typename T>
structures::LinkedList<T>::LinkedList() {
    head = nullptr;
    size_ = 0;
}

template<typename T>
structures::LinkedList<T>::~LinkedList() {
    clear();
}

template<typename T>
void structures::LinkedList<T>::clear() {
    while (!empty()) {
        pop_front();
    }
}

template<typename T>
void structures::LinkedList<T>::push_back(const T& data) {
    Node* new_node = new Node(data);
    if (empty()) {
        head = new_node;
    } else {
        end()->next(new_node);
    }
    size_++;
}

template<typename T>
void structures::LinkedList<T>::push_front(const T& data) {
    Node* new_node = new Node(data);
    new_node->next(head);
    head = new_node;
    size_++;
}

template<typename T>
void structures::LinkedList<T>::insert(const T& data, std::size_t index) {
    if (index > size_) {
        throw std::out_of_range("Index out of range");
    }
    if (index == 0) {
        push_front(data);
    } else if (index == size_) {
        push_back(data);
    } else {
        Node* new_node = new Node(data);
        Node* previous = head;
        for (std::size_t i = 0; i < index - 1; i++) {
            previous = previous->next();
        }
        new_node->next(previous->next());
        previous->next(new_node);
        size_++;
    }
}

template<typename T>
void structures::LinkedList<T>::insert_sorted(const T& data) {
    Node* new_node = new Node(data);
    if (empty() || data <= head->data()) {
        push_front(data);
    } else {
        Node* current = head;
        while (current->next() != nullptr && data > current->next()->data()) {
            current = current->next();
        }
        new_node->next(current->next());
        current->next(new_node);
        size_++;
    }
}

template<typename T>
T& structures::LinkedList<T>::at(std::size_t index) {
    if (index >= size_) {
        throw std::out_of_range("Index out of range");
    }
    Node* current = head;
    for (std::size_t i = 0; i < index; i++) {
        current = current->next();
    }
    return current->data();
}

template<typename T>
T structures::LinkedList<T>::pop(std::size_t index) {
    if (index >= size_) {
        throw std::out_of_range("Index out of range");
    }
    if (index == 0) {
        return pop_front();
    } else if (index == size_ - 1) {
        return pop_back();
    } else {
        Node* previous = head;
        for (std::size_t i = 0; i < index - 1; i++) {
            previous = previous->next();
        }
        Node* to_remove = previous->next();
        T data = to_remove->data();
        previous->next(to_remove->next());
        delete to_remove;
        size_--;
        return data;
    }
}

template<typename T>
T structures::LinkedList<T>::pop_back() {
    if (empty()) {
        throw std::out_of_range("List is empty");
    }
    if (size_ == 1) {
        T data = head->data();
        delete head;
        head = nullptr;
        size_ = 0;
        return data;
    } else {
        Node* previous = head;
        while (previous->next()->next() != nullptr) {
            previous = previous->next();
        }
        Node* to_remove = previous->next();
        T data = to_remove->data();
        previous->next(nullptr);
        delete to_remove;
        size_--;
        return data;
    }
}

template<typename T>
T structures::LinkedList<T>::pop_front() {
    if (empty()) {
        throw std::out_of_range("List is empty");
    }
    Node* to_remove = head;
    T data = to_remove->data();
    head = head->next();
    delete to_remove;
    size_--;
    return data;
}

template<typename T>
void structures::LinkedList<T>::remove(const T& data) {
    if (empty()) {
        throw std::out_of_range("List is empty");
    }
    if (data == head->data()) {
        pop_front();
    } else {
        Node* previous = head;
        while (previous->next() != nullptr
        && previous->next()->data() != data) {
            previous = previous->next();
        }
        if (previous->next() != nullptr) {
            Node* to_remove = previous->next();
            previous->next(to_remove->next());
            delete to_remove;
            size_--;
        }
    }
}

template<typename T>
bool structures::LinkedList<T>::empty() const {
    return size_ == 0;
}

template<typename T>
bool structures::LinkedList<T>::contains(const T& data) const {
    Node* current = head;
    while (current != nullptr) {
        if (current->data() == data) {
            return true;
        }
        current = current->next();
    }
    return false;
}

template<typename T>
std::size_t structures::LinkedList<T>::find(const T& data) const {
    Node* current = head;
    std::size_t index = 0;
    while (current != nullptr) {
        if (current->data() == data) {
            return index;
        }
        current = current->next();
        index++;
    }
    return size_;
}

template<typename T>
std::size_t structures::LinkedList<T>::size() const {
    return size_;
}