#ifndef STRUCTURES_ARRAY_LIST_H
#define STRUCTURES_ARRAY_LIST_H

#include <cstdint>


namespace structures {

template<typename T>
class ArrayList {
public:
    ArrayList();
    explicit ArrayList(std::size_t max_size);
    ~ArrayList();

    void clear();
    void push_back(const T& data);
    void push_front(const T& data);
    void insert(const T& data, std::size_t index);
    void insert_sorted(const T& data);
    T pop(std::size_t index);
    T pop_back();
    T pop_front();
    void remove(const T& data);
    bool full() const;
    bool empty() const;
    bool contains(const T& data) const;
    std::size_t find(const T& data) const;
    std::size_t size() const;
    std::size_t max_size() const;
    T& at(std::size_t index);
    T& operator[](std::size_t index);
    const T& at(std::size_t index) const;
    const T& operator[](std::size_t index) const;
    // descricao do 'operator []' na FAQ da disciplina

private:
    T* contents;
    std::size_t size_;
    std::size_t max_size_;

    static const auto DEFAULT_MAX = 10u;
};

}

#endif

template<typename T>
bool structures::ArrayList() : ArrayList(DEFAULT_SIZE) {}

template<typename T>
structures::ArrayList<T>::ArrayList() : ArrayList(DEFAULT_SIZE) {}

template<typename T>
structures::ArrayList<T>::ArrayList(std::size_t max) {
    max_size_ = max;
    contents = new T[max_size_];
    size_ = -1;
}

template<typename T>
structures::ArrayList<T>::~ArrayList() {
    delete [] contents;
}

template<typename T>
void structures::ArrayList<T>::enqueue(const T& data) {
    if (full()) {
        throw std::out_of_range("fila cheia");
    } else {
        size_++;
        end_ = (end_+ 1) % max_size_;
        contents[size_] = data;
    }
}

template<typename T>
T structures::ArrayList<T>::dequeue() {
    if (empty()) throw std::out_of_range("fila vazia");
    T data = contents[begin_];

    begin_ = (begin_ + 1) % max_size_;
    size_--;
    return data;
}

template<typename T>
T& structures::ArrayList<T>::back() {
    if (empty())
        throw std::out_of_range("fila vazia");
    return contents[size_];
}

template<typename T>
void structures::ArrayList<T>::clear() {
    size_ = -1;
    begin_ = 1;
    end_ = 0;
}

template<typename T>
std::size_t structures::ArrayList<T>::size() {
    return size_ + 1;
}

template<typename T>
std::size_t structures::ArrayList<T>::max_size() {
    return max_size_;
}

template<typename T>
bool structures::ArrayList<T>::empty() {
    return (static_cast<int>(size_) == -1);
}

template<typename T>
bool structures::ArrayList<T>::full() {
    return static_cast<std::size_t>(size_) == max_size() - 1;
}
