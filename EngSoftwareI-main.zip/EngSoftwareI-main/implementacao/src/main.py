from playerInterface import PlayerInterface

if __name__ == "__main__":
    player = PlayerInterface()
    player.mainloop()
